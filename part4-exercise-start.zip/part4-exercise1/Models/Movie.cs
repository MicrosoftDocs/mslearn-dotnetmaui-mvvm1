﻿namespace MovieCatalog.Models;

public record Movie(string Title, string Studio, string Director, int Year);
